const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');
const https = require('https');

// Polyfill fetch for older Node.js versions (like v13.14.0 on Windows 7)
if (typeof fetch === 'undefined') {
    globalThis.fetch = function (url, options = {}) {
        return new Promise((resolve, reject) => {
            try {
                const { URL } = require('url');
                const urlObj = new URL(url);
                const reqOptions = {
                    method: options.method || 'GET',
                    headers: options.headers || {},
                    host: urlObj.hostname,
                    path: urlObj.pathname + urlObj.search,
                    port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80)
                };

                const req = https.request(reqOptions, (res) => {
                    let data = '';
                    res.on('data', (chunk) => { data += chunk; });
                    res.on('end', () => {
                        resolve({
                            ok: res.statusCode >= 200 && res.statusCode < 300,
                            status: res.statusCode,
                            text: () => Promise.resolve(data),
                            json: () => Promise.resolve(JSON.parse(data))
                        });
                    });
                });

                req.on('error', (err) => {
                    reject(err);
                });

                if (options.body) {
                    req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
                }
                req.end();
            } catch (err) {
                reject(err);
            }
        });
    };
}

const app = express();
const PORT = process.env.PORT || 3000;
const FIREBASE_URL = 'https://tawajen-foush-default-rtdb.firebaseio.com/foush.json';

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' })); // Allow large JSON uploads for POS state

// Database Connection
const dbPath = path.resolve(__dirname, 'foush.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        // Initialize state table for Hybrid Sync
        db.run('CREATE TABLE IF NOT EXISTS app_state (id INTEGER PRIMARY KEY, version INTEGER, hash TEXT, data TEXT)');
        db.run('CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, cashier TEXT, time INTEGER, total REAL, discount REAL, paid INTEGER, paymentMethod TEXT, status TEXT)');
        db.run('CREATE TABLE IF NOT EXISTS order_items (order_id TEXT, name TEXT, price REAL, qty INTEGER, PRIMARY KEY(order_id, name))');
        
        // Seed first state if empty
        db.get('SELECT version FROM app_state WHERE id = 1', (err, row) => {
            if (!row) {
                db.run("INSERT INTO app_state (id, version, hash, data) VALUES (1, 1, 'init', '{}')");
            }
        });
    }
});

// Serve the frontend statically
app.use(express.static(path.join(__dirname, '../')));

// ---------------------------------------------------------
// Cloud Sync Engine (Phase 3)
// ---------------------------------------------------------
let syncNeeded = false;
let syncInProgress = false;

// Background loop to push data to Firebase when internet is available
setInterval(async () => {
    if (!syncNeeded || syncInProgress) return;
    
    syncInProgress = true;
    db.get('SELECT data FROM app_state WHERE id = 1', async (err, row) => {
        if (err || !row) {
            syncInProgress = false;
            return;
        }
        
        try {
            console.log("☁️ Attempting to sync to Cloud (Firebase)...");
            const response = await fetch(FIREBASE_URL, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: row.data
            });
            
            if (response.ok) {
                console.log("✅ Cloud Sync Successful!");
                syncNeeded = false; // Successfully synced!
            } else {
                console.warn("⚠️ Cloud Sync Failed. Will retry later. Status:", response.status);
            }
        } catch (e) {
            console.warn("🌐 No Internet or connection error. Cloud Sync paused. Data is safe locally.");
        } finally {
            syncInProgress = false;
        }
    });
}, 10000); // Check queue every 10 seconds

// ---------------------------------------------------------
// Hybrid Sync API (Used by pos.html natively)
// ---------------------------------------------------------

app.get('/api/ping', (req, res) => {
    res.json({ ok: true });
});

let isZkConnected = false;

app.get('/api/version', (req, res) => {
    db.get('SELECT version, hash FROM app_state WHERE id = 1', (err, row) => {
        if (err || !row) return res.status(500).json({ error: err ? err.message : 'No state' });
        res.json({ v: row.version, h: row.hash, zkConnected: isZkConnected });
    });
});

app.get('/api/db', (req, res) => {
    db.get('SELECT data FROM app_state WHERE id = 1', (err, row) => {
        if (err || !row) return res.status(500).json({ error: err ? err.message : 'No data' });
        try {
            const parsed = JSON.parse(row.data);
            parsed._zkConnected = isZkConnected; // Inject ZK device status for frontend badge
            res.json(parsed);
        } catch (e) {
            res.json({ _zkConnected: false });
        }
    });
});

app.post('/api/db', (req, res) => {
    const rawData = JSON.stringify(req.body);
    const hash = crypto.createHash('md5').update(rawData).digest('hex');
    
    db.get('SELECT version, hash FROM app_state WHERE id = 1', (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        
        // Only update if hash changed
        if (row && row.hash === hash) {
            return res.json({ ok: true, v: row.version, h: row.hash });
        }
        
        const newVersion = (row ? row.version : 0) + 1;
        db.run('UPDATE app_state SET version = ?, hash = ?, data = ? WHERE id = 1', [newVersion, hash, rawData], function(err) {
            if (err) return res.status(500).json({ error: err.message });
            
            // Trigger cloud sync in the background!
            syncNeeded = true;
            
            // Asynchronously sync to relational tables for local reporting
            syncRelationalTables(req.body);
            
            res.json({ ok: true, v: newVersion, h: hash });
        });
    });
});

function syncRelationalTables(data) {
    if (!data) return;
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        
        // Extract orders
        if (data.orders || data.historical_orders) {
            const allOrders = [...(data.orders || []), ...(data.historical_orders || [])];
            const stmtOrder = db.prepare('INSERT OR REPLACE INTO orders (id, cashier, time, total, discount, paid, paymentMethod, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            const stmtItems = db.prepare('INSERT OR IGNORE INTO order_items (order_id, name, price, qty) VALUES (?, ?, ?, ?)');
            
            for (let o of allOrders) {
                stmtOrder.run(o.id, o.cashier || null, o.time || 0, o.total || 0, o.discount || 0, o.paid ? 1 : 0, o.paymentMethod || null, o.status || null);
                if (o.items) {
                    for (let i of o.items) {
                        stmtItems.run(o.id, i.name, i.price, i.qty);
                    }
                } else if (o.cart) {
                    for (let i of o.cart) {
                        stmtItems.run(o.id, i.name, i.price, i.qty);
                    }
                }
            }
            stmtOrder.finalize();
            stmtItems.finalize();
        }
        
        db.run('COMMIT');
    });
}

// GET /api/health (Remote Monitoring Layer Hook)
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', uptime: process.uptime(), timestamp: Date.now() });
});

// POST /api/zk/sync (Force poll and sync ZKTeco device)
app.post('/api/zk/sync', async (req, res) => {
    try {
        if (!ZKLib) {
            return res.status(400).json({ error: 'ZKTeco library (node-zklib) is not loaded on this machine.' });
        }
        console.log(`🔌 Force sync requested. Connecting to ZKTeco at ${ZK_IP}:${ZK_PORT}...`);
        let zkInstance = new ZKLib({ ip: ZK_IP, port: ZK_PORT, timeout: 5000, inport: 5200 });
        await zkInstance.createSocket();
        const attendances = await zkInstance.getAttendances();
        let count = 0;
        if (attendances && attendances.data) {
            isZkConnected = true;
            if (attendances.data.length > 0) {
                processAttendanceLogs(attendances.data);
                count = attendances.data.length;
            }
        }
        await zkInstance.disconnect();
        res.json({ success: true, count: count });
    } catch (e) {
        console.error('❌ Force sync failed:', e.message);
        isZkConnected = false;
        res.status(500).json({ error: 'Failed to connect to the fingerprint device. Make sure it is powered on and connected to the same network.' });
    }
});

// POST /api/db/clear (Clear mock transactional data, preserve menu/employees)
app.post('/api/db/clear', (req, res) => {
    db.get('SELECT data FROM app_state WHERE id = 1', (err, row) => {
        if (err || !row) return res.status(500).json({ error: err ? err.message : 'No database state' });
        
        let data;
        try {
            data = JSON.parse(row.data);
        } catch(e) {
            data = {};
        }

        const cleanState = {
            menu: data.menu || [],
            employees: data.employees || [],
            tables: data.tables || [],
            settings: data.settings || {},
            orders: [],
            shift: null,
            historical_orders: [],
            exp: [],
            shifts_history: [],
            stock_history: [],
            waste_log: [],
            attendance: data.attendance || []
        };

        const rawData = JSON.stringify(cleanState);
        const newHash = crypto.createHash('md5').update(rawData).digest('hex');

        db.get('SELECT version FROM app_state WHERE id = 1', (err, stateRow) => {
            const nextVersion = (stateRow ? stateRow.version : 0) + 1;
            
            db.serialize(() => {
                db.run('BEGIN TRANSACTION');
                db.run('UPDATE app_state SET version = ?, hash = ?, data = ? WHERE id = 1', [nextVersion, newHash, rawData]);
                db.run('DELETE FROM orders');
                db.run('DELETE FROM order_items');
                db.run('COMMIT', (commitErr) => {
                    if (commitErr) {
                        return res.status(500).json({ error: commitErr.message });
                    }
                    syncNeeded = true;
                    res.json({ ok: true, version: nextVersion });
                });
            });
        });
    });
});

// POST /api/db/generate-mock (Populate database with 90 days of mock sales and expenses)
app.post('/api/db/generate-mock', (req, res) => {
    db.get('SELECT data FROM app_state WHERE id = 1', (err, row) => {
        if (err || !row) return res.status(500).json({ error: err ? err.message : 'No database state' });
        
        let data;
        try {
            data = JSON.parse(row.data);
        } catch(e) {
            data = {};
        }

        const menu = data.menu || [];
        const employees = data.employees || [];
        const tables = data.tables || [];
        const settings = data.settings || {};

        const now = Date.now();
        const DAY = 24 * 60 * 60 * 1000;
        const NumDays = 90;

        const historical_orders = [];
        const exp = [];
        const shifts_history = [];

        const generalExpNames = ['شاي وسكر وعينات كافية', 'أدوات تنظيف وصابون', 'فواتير مياه وصرف صحي', 'شراء مطبوعات وفواتير الكاشير', 'مصروفات ضيافة ونثريات'];
        const rawMaterialNames = ['شراء لحوم وخضار طازجة', 'شراء أرز وزيت وتوابل', 'شراء مأكولات ومقادير طهي', 'شراء طواجن فخار جديدة', 'مشتريات من سوق الخضار'];
        const emergencyNames = ['صيانة سباكة ومواسير حمام', 'إصلاح خلاط كهربائي ومعدات مطبخ', 'إصلاح إنارة وإضاءة صالة الكاشير', 'صيانة شفاط المطبخ والتكييف'];

        for (let i = NumDays - 1; i >= 0; i--) {
            const baseTime = now - (i * DAY);
            const dateObj = new Date(baseTime);
            dateObj.setHours(12, 0, 0, 0);
            const shiftStart = dateObj.getTime();
            const shiftEnd = shiftStart + (9 * 60 * 60 * 1000);

            let totalShiftSales = 0;
            let totalShiftCashSales = 0;
            let totalShiftVisaSales = 0;
            let totalShiftWalletSales = 0;
            let totalShiftExp = 0;

            const numOrders = Math.floor(Math.random() * 21) + 18;
            for (let o = 0; o < numOrders; o++) {
                const orderTime = shiftStart + Math.random() * (shiftEnd - shiftStart);
                const cartItems = [];
                const numCartItems = menu.length > 0 ? Math.floor(Math.random() * Math.min(3, menu.length)) + 1 : 0;
                let orderTotal = 0;

                const selectedIndices = new Set();
                while (cartItems.length < numCartItems) {
                    const idx = Math.floor(Math.random() * menu.length);
                    if (selectedIndices.has(idx)) continue;
                    selectedIndices.add(idx);
                    const menuItem = menu[idx];
                    const qty = Math.floor(Math.random() * 2) + 1;
                    const itemTotal = menuItem.price * qty;
                    orderTotal += itemTotal;
                    cartItems.push({
                        id: menuItem.id,
                        name: menuItem.name,
                        price: menuItem.price,
                        qty: qty,
                        category: menuItem.category
                    });
                }

                const paymentRand = Math.random();
                let paymentMethod = 'cash';
                if (paymentRand > 0.85) {
                    paymentMethod = 'wallet';
                } else if (paymentRand > 0.65) {
                    paymentMethod = 'visa';
                }

                let discount = 0;
                if (Math.random() > 0.9) {
                    discount = Math.floor(orderTotal * 0.1);
                }
                const netTotal = orderTotal - discount;

                totalShiftSales += netTotal;
                if (paymentMethod === 'cash') totalShiftCashSales += netTotal;
                if (paymentMethod === 'visa') totalShiftVisaSales += netTotal;
                if (paymentMethod === 'wallet') totalShiftWalletSales += netTotal;

                historical_orders.push({
                    id: 'ORD-' + dateObj.getFullYear() + String(dateObj.getMonth() + 1).padStart(2, '0') + String(dateObj.getDate()).padStart(2, '0') + '-' + String(o + 1).padStart(3, '0'),
                    time: orderTime,
                    total: netTotal,
                    discount: discount,
                    paid: true,
                    status: 'completed',
                    cashier: 'احمد',
                    paymentMethod: paymentMethod,
                    type: Math.random() > 0.6 ? 'takeaway' : (Math.random() > 0.5 ? 'dine-in' : 'delivery'),
                    items: cartItems,
                    shiftStart: shiftStart
                });
            }

            const dailyGeneralAmt = Math.floor(Math.random() * 61) + 40;
            const generalName = generalExpNames[Math.floor(Math.random() * generalExpNames.length)];
            exp.push({
                type: 'general',
                category: 'مصروف عام',
                name: generalName,
                details: 'منصرف نثري يومي لتسيير الصالة',
                amount: dailyGeneralAmt,
                time: shiftStart + (3 * 60 * 60 * 1000),
                isShiftExpense: true
            });
            totalShiftExp += dailyGeneralAmt;

            if (i % 2 === 0) {
                const rawAmt = Math.floor(Math.random() * 801) + 800;
                const rawName = rawMaterialNames[Math.floor(Math.random() * rawMaterialNames.length)];
                exp.push({
                    type: 'inventory',
                    category: 'شراء خامات',
                    name: rawName,
                    details: 'شراء مواد خام ومستلزمات الطبخ اليومية',
                    amount: rawAmt,
                    time: shiftStart + (1 * 60 * 60 * 1000),
                    isShiftExpense: false
                });
            }

            if (i % 30 === 5) {
                const salaryAmt = employees.reduce((s, e) => s + (e.salary || 5000), 0) + 1500;
                exp.push({
                    type: 'salaries',
                    category: 'مرتبات',
                    name: 'صرف مرتبات الموظفين وسلف العاملين',
                    details: 'صرف مرتبات الموظفين الشهرية مع المكافآت',
                    amount: salaryAmt,
                    time: shiftStart + (5 * 60 * 60 * 1000),
                    isShiftExpense: false
                });
            }

            if (i % 12 === 3) {
                const emergencyAmt = Math.floor(Math.random() * 351) + 150;
                const emergencyName = emergencyNames[Math.floor(Math.random() * emergencyNames.length)];
                exp.push({
                    type: 'emergency',
                    category: 'طوارئ',
                    name: emergencyName,
                    details: 'مصروفات إصلاح وصيانة طارئة بالمحل',
                    amount: emergencyAmt,
                    time: shiftStart + (6 * 60 * 60 * 1000),
                    isShiftExpense: true
                });
                totalShiftExp += emergencyAmt;
            }

            shifts_history.push({
                start: shiftStart,
                end: shiftEnd,
                sales: totalShiftSales,
                netSales: totalShiftSales,
                cashSales: totalShiftCashSales,
                visaSales: totalShiftVisaSales,
                walletSales: totalShiftWalletSales,
                expenses: totalShiftExp,
                net: totalShiftCashSales - totalShiftExp,
                wasteCount: 0,
                wasteDetails: []
            });
        }

        const newState = {
            ...data,
            menu: menu,
            employees: employees,
            tables: tables,
            settings: settings,
            orders: [],
            shift: null,
            historical_orders: historical_orders,
            exp: exp,
            shifts_history: shifts_history
        };

        const rawData = JSON.stringify(newState);
        const newHash = crypto.createHash('md5').update(rawData).digest('hex');

        db.get('SELECT version FROM app_state WHERE id = 1', (err, stateRow) => {
            const nextVersion = (stateRow ? stateRow.version : 0) + 1;
            
            db.serialize(() => {
                db.run('BEGIN TRANSACTION');
                db.run('UPDATE app_state SET version = ?, hash = ?, data = ? WHERE id = 1', [nextVersion, newHash, rawData]);
                db.run('DELETE FROM orders');
                db.run('DELETE FROM order_items');

                const stmtOrder = db.prepare('INSERT OR REPLACE INTO orders (id, cashier, time, total, discount, paid, paymentMethod, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                const stmtItems = db.prepare('INSERT OR IGNORE INTO order_items (order_id, name, price, qty) VALUES (?, ?, ?, ?)');

                for (let o of historical_orders) {
                    stmtOrder.run(o.id, o.cashier || null, o.time || 0, o.total || 0, o.discount || 0, o.paid ? 1 : 0, o.paymentMethod || null, o.status || null);
                    if (o.items) {
                        for (let i of o.items) {
                            stmtItems.run(o.id, i.name, i.price, i.qty);
                        }
                    }
                }
                stmtOrder.finalize();
                stmtItems.finalize();

                db.run('COMMIT', (commitErr) => {
                    if (commitErr) {
                        return res.status(500).json({ error: commitErr.message });
                    }
                    syncNeeded = true;
                    res.json({ ok: true, version: nextVersion });
                });
            });
        });
    });
});

// Start Server
app.listen(PORT, '0.0.0.0', async () => {
    console.log(`Foush Local Server running on http://0.0.0.0:${PORT}`);
    
    // Start Secure Tunnel for Remote Access
    try {
        const localtunnel = require('localtunnel');
        const fs = require('fs');
        
        // Use a fixed subdomain so the manager can bookmark it
        const tunnel = await localtunnel({ port: PORT, subdomain: 'tawajen-foush' });
        
        console.log(`🌍 Remote Access Link: ${tunnel.url}`);
        
        // Write the link to a file on Desktop for easy access inside the restaurant
        const desktopPath = path.join(require('os').homedir(), 'Desktop', 'Remote_Access_Link.txt');
        const msg = `رابط الدخول على نظام المطعم عن بعد:\n\n${tunnel.url}\n\n* احتفظ بهذا الرابط (أو احفظه في المتصفح) لكي تتمكن من الدخول إلى المطعم وأنت في المنزل.\n* عند فتح الرابط لأول مرة، قد تظهر لك صفحة تحذيرية من الموقع، فقط اضغط على زر "Click to Continue" للدخول للنظام.`;
        fs.writeFileSync(desktopPath, msg);
        console.log(`✅ Saved link to Desktop: Remote_Access_Link.txt`);
        
        tunnel.on('close', () => {
            console.log('Tunnel closed.');
        });
    } catch (e) {
        console.error('Failed to start remote tunnel:', e);
    }
});

// ---------------------------------------------------------
// ZKTeco Fingerprint Integration
// ---------------------------------------------------------
const fs = require('fs');
let ZK_IP = '192.168.1.201'; // Default IP of the ZKTeco device
let ZK_PORT = 4370;

// Load ZKTeco configurations from config.json if present
const configPath = path.resolve(__dirname, 'config.json');
if (fs.existsSync(configPath)) {
    try {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (config.zkIP) ZK_IP = config.zkIP;
        if (config.zkPort) ZK_PORT = config.zkPort;
        console.log(`ℹ️ Loaded fingerprint config: IP=${ZK_IP}, Port=${ZK_PORT}`);
    } catch (e) {
        console.warn('⚠️ Error reading config.json, using defaults.');
    }
}

let ZKLib;
try {
    ZKLib = require('node-zklib');
    console.log('✅ ZKTeco Library loaded successfully.');
    startZKPolling();
} catch (e) {
    console.log('⚠️ ZKTeco Library (node-zklib) not installed. Fingerprint integration is disabled.');
    console.log('   Run `npm install node-zklib` on the final machine to enable it.');
}

function startZKPolling() {
    setInterval(async () => {
        try {
            let zkInstance = new ZKLib({ ip: ZK_IP, port: ZK_PORT, timeout: 5000, inport: 5200 });
            await zkInstance.createSocket();
            const attendances = await zkInstance.getAttendances();
            if (attendances && attendances.data) {
                isZkConnected = true;
                if (attendances.data.length > 0) {
                    processAttendanceLogs(attendances.data);
                }
            }
            await zkInstance.disconnect();
        } catch (e) {
            isZkConnected = false;
        }
    }, 60000); // Check every 1 minute
}

function processAttendanceLogs(logs) {
    logs.sort((a, b) => new Date(a.recordTime).getTime() - new Date(b.recordTime).getTime());
    
    db.get('SELECT version, hash, data FROM app_state WHERE id = 1', (err, row) => {
        if (err || !row || !row.data) return;
        
        try {
            let appData = JSON.parse(row.data);
            if (!appData.attendance) appData.attendance = [];
            
            let changed = false;
            
            logs.forEach((log) => {
                 const logTimestamp = new Date(log.recordTime).getTime();
                 const existing = appData.attendance.find(a => String(a.empId) === String(log.deviceUserId) && Math.abs(a.time - logTimestamp) < 2000);
                 
                 if (!existing) {
                     const lastRecord = [...appData.attendance].reverse().find(a => String(a.empId) === String(log.deviceUserId));
                     const newType = (lastRecord && lastRecord.type === 'in') ? 'out' : 'in';
                     
                     appData.attendance.push({
                         empId: log.deviceUserId,
                         type: newType,
                         time: logTimestamp,
                         isZk: true
                     });
                     changed = true;
                 }
            });
            
            if (changed) {
                const newDataStr = JSON.stringify(appData);
                const newHash = require('crypto').createHash('md5').update(newDataStr).digest('hex');
                const newVersion = row.version + 1;
                
                db.run('UPDATE app_state SET version = ?, hash = ?, data = ? WHERE id = 1', [newVersion, newHash, newDataStr], function(err) {
                    if (!err) {
                        console.log('✅ Synchronized new attendance records from ZKTeco!');
                        syncNeeded = true;
                    }
                });
            }
        } catch(e) {
            console.error("Error processing ZK logs:", e);
        }
    });
}
