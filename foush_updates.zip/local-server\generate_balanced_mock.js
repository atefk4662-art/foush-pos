const sqlite3 = require('sqlite3').verbose();
const crypto = require('crypto');
const path = require('path');

const dbPath = path.resolve(__dirname, 'foush.db');
const db = new sqlite3.Database(dbPath);

db.get('SELECT data FROM app_state WHERE id = 1', (err, row) => {
    if (err || !row) {
        console.error("Database error or no state row:", err);
        process.exit(1);
    }

    let data;
    try {
        data = JSON.parse(row.data);
    } catch(e) {
        data = {};
    }

    // Preserve core static configs
    const menu = data.menu || [
        { id: 1, name: 'طاجن لحم', price: 250, category: 'طواجن', stock: 100 },
        { id: 2, name: 'أرز بالشعيرية', price: 40, category: 'أرز وفتة', stock: 100, unlimited: true },
        { id: 3, name: 'شوربة طواجن', price: 60, category: 'شوربة', stock: 100 },
        { id: 1782478730795, name: 'طاجن عاكوي', price: 200, category: 'طواجن', stock: 5, unlimited: false }
    ];
    const employees = data.employees || [
        { id: 1782480699900, name: 'احمد', role: 'kitchen', pin: '2222', salary: 5000, zkId: '2' }
    ];
    const tables = data.tables || [];
    const settings = data.settings || {};

    const now = Date.now();
    const DAY = 24 * 60 * 60 * 1000;
    const NumDays = 90;

    const historical_orders = [];
    const exp = [];
    const shifts_history = [];

    // Names for random expenses
    const generalExpNames = ['شاي وسكر وعينات كافية', 'أدوات تنظيف وصابون', 'فواتير مياه وصرف صحي', 'شراء مطبوعات وفواتير الكاشير', 'مصروفات ضيافة ونثريات'];
    const rawMaterialNames = ['شراء لحوم وخضار طازجة', 'شراء أرز وزيت وتوابل', 'شراء مأكولات ومقادير طهي', 'شراء طواجن فخار جديدة', 'مشتريات من سوق الخضار'];
    const emergencyNames = ['صيانة سباكة ومواسير حمام', 'إصلاح خلاط كهربائي ومعدات مطبخ', 'إصلاح إنارة وإضاءة صالة الكاشير', 'صيانة شفاط المطبخ والتكييف'];

    for (let i = NumDays - 1; i >= 0; i--) {
        // Shift start time around 12:00 PM for each day in the past
        const baseTime = now - (i * DAY);
        const dateObj = new Date(baseTime);
        dateObj.setHours(12, 0, 0, 0);
        const shiftStart = dateObj.getTime();
        const shiftEnd = shiftStart + (9 * 60 * 60 * 1000); // 9 hour shift (closes at 9:00 PM)

        let totalShiftSales = 0;
        let totalShiftCashSales = 0;
        let totalShiftVisaSales = 0;
        let totalShiftWalletSales = 0;
        let totalShiftExp = 0;

        // Generate 18 to 38 orders per day
        const numOrders = Math.floor(Math.random() * 21) + 18;
        for (let o = 0; o < numOrders; o++) {
            const orderTime = shiftStart + Math.random() * (shiftEnd - shiftStart);
            
            // Build items list
            const cartItems = [];
            const numCartItems = Math.floor(Math.random() * 3) + 1; // 1 to 3 items
            let orderTotal = 0;

            const selectedIndices = new Set();
            while (cartItems.length < numCartItems) {
                const idx = Math.floor(Math.random() * menu.length);
                if (selectedIndices.has(idx)) continue;
                selectedIndices.add(idx);
                const menuItem = menu[idx];
                const qty = Math.floor(Math.random() * 2) + 1; // 1 or 2 items
                const itemTotal = menuItem.price * qty;
                orderTotal += itemTotal;
                cartItems.push({
                    id: menuItem.id,
                    name: menuItem.name,
                    price: menuItem.price,
                    qty: qty,
                    category: menuItem.category
                });
            }

            const paymentRand = Math.random();
            let paymentMethod = 'cash';
            if (paymentRand > 0.85) {
                paymentMethod = 'wallet';
            } else if (paymentRand > 0.65) {
                paymentMethod = 'visa';
            }

            // Apply minor discount occasionally (5%)
            let discount = 0;
            if (Math.random() > 0.9) {
                discount = Math.floor(orderTotal * 0.1);
            }
            const netTotal = orderTotal - discount;

            totalShiftSales += netTotal;
            if (paymentMethod === 'cash') totalShiftCashSales += netTotal;
            if (paymentMethod === 'visa') totalShiftVisaSales += netTotal;
            if (paymentMethod === 'wallet') totalShiftWalletSales += netTotal;

            historical_orders.push({
                id: 'ORD-' + dateObj.getFullYear() + String(dateObj.getMonth() + 1).padStart(2, '0') + String(dateObj.getDate()).padStart(2, '0') + '-' + String(o + 1).padStart(3, '0'),
                time: orderTime,
                total: netTotal,
                discount: discount,
                paid: true,
                status: 'completed',
                cashier: 'احمد',
                paymentMethod: paymentMethod,
                type: Math.random() > 0.6 ? 'takeaway' : (Math.random() > 0.5 ? 'dine-in' : 'delivery'),
                items: cartItems,
                shiftStart: shiftStart
            });
        }

        // Expenses for this day
        // 1. Daily general expense (small scale)
        const dailyGeneralAmt = Math.floor(Math.random() * 61) + 40; // 40 - 100
        const generalName = generalExpNames[Math.floor(Math.random() * generalExpNames.length)];
        exp.push({
            type: 'general',
            category: 'مصروف عام',
            name: generalName,
            details: 'منصرف نثري يومي لتسيير الصالة',
            amount: dailyGeneralAmt,
            time: shiftStart + (3 * 60 * 60 * 1000), // 3 hours after shift start
            isShiftExpense: true
        });
        totalShiftExp += dailyGeneralAmt;

        // 2. Raw materials purchase every 2 days
        if (i % 2 === 0) {
            const rawAmt = Math.floor(Math.random() * 801) + 800; // 800 - 1600
            const rawName = rawMaterialNames[Math.floor(Math.random() * rawMaterialNames.length)];
            exp.push({
                type: 'inventory',
                category: 'شراء خامات',
                name: rawName,
                details: 'شراء مواد خام ومستلزمات الطبخ اليومية',
                amount: rawAmt,
                time: shiftStart + (1 * 60 * 60 * 1000), // 1 hour after shift start
                isShiftExpense: false
            });
        }

        // 3. Salaries once every 30 days
        if (i % 30 === 5) {
            const salaryAmt = employees.reduce((s, e) => s + (e.salary || 5000), 0) + 1500; // salary total + extras
            exp.push({
                type: 'salaries',
                category: 'مرتبات',
                name: 'صرف مرتبات الموظفين وسلف العاملين',
                details: 'صرف مرتبات الموظفين الشهرية مع المكافآت',
                amount: salaryAmt,
                time: shiftStart + (5 * 60 * 60 * 1000),
                isShiftExpense: false
            });
        }

        // 4. Emergency expense every 12 days
        if (i % 12 === 3) {
            const emergencyAmt = Math.floor(Math.random() * 351) + 150; // 150 - 500
            const emergencyName = emergencyNames[Math.floor(Math.random() * emergencyNames.length)];
            exp.push({
                type: 'emergency',
                category: 'طوارئ',
                name: emergencyName,
                details: 'مصروفات إصلاح وصيانة طارئة بالمحل',
                amount: emergencyAmt,
                time: shiftStart + (6 * 60 * 60 * 1000),
                isShiftExpense: true
            });
            totalShiftExp += emergencyAmt;
        }

        // Generate shift history record
        shifts_history.push({
            start: shiftStart,
            end: shiftEnd,
            sales: totalShiftSales,
            netSales: totalShiftSales,
            cashSales: totalShiftCashSales,
            visaSales: totalShiftVisaSales,
            walletSales: totalShiftWalletSales,
            expenses: totalShiftExp,
            net: totalShiftCashSales - totalShiftExp,
            wasteCount: 0,
            wasteDetails: []
        });
    }

    // Build the new state
    const newState = {
        ...data,
        menu: menu,
        employees: employees,
        tables: tables,
        settings: settings,
        orders: [],
        shift: null,
        historical_orders: historical_orders,
        exp: exp,
        shifts_history: shifts_history
    };

    const rawData = JSON.stringify(newState);
    const newHash = crypto.createHash('md5').update(rawData).digest('hex');

    db.get('SELECT version FROM app_state WHERE id = 1', (err, stateRow) => {
        const nextVersion = (stateRow ? stateRow.version : 0) + 1;
        
        db.serialize(() => {
            db.run('BEGIN TRANSACTION');
            
            // 1. Update JSON state
            db.run('UPDATE app_state SET version = ?, hash = ?, data = ? WHERE id = 1', [nextVersion, newHash, rawData], function(updateErr) {
                if (updateErr) {
                    console.error("Failed to update JSON state:", updateErr);
                    db.run('ROLLBACK');
                    process.exit(1);
                }
                console.log("JSON state row updated. Version:", nextVersion);
            });

            // 2. Clear SQL relational reporting tables
            db.run('DELETE FROM orders');
            db.run('DELETE FROM order_items');
            console.log("Cleared relational tables.");

            // 3. Re-insert all generated orders into SQLite relational tables
            const stmtOrder = db.prepare('INSERT OR REPLACE INTO orders (id, cashier, time, total, discount, paid, paymentMethod, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            const stmtItems = db.prepare('INSERT OR IGNORE INTO order_items (order_id, name, price, qty) VALUES (?, ?, ?, ?)');

            for (let o of historical_orders) {
                stmtOrder.run(o.id, o.cashier || null, o.time || 0, o.total || 0, o.discount || 0, o.paid ? 1 : 0, o.paymentMethod || null, o.status || null);
                if (o.items) {
                    for (let i of o.items) {
                        stmtItems.run(o.id, i.name, i.price, i.qty);
                    }
                }
            }
            stmtOrder.finalize();
            stmtItems.finalize();
            console.log("Inserted all generated mock orders into relational tables.");

            db.run('COMMIT', (commitErr) => {
                if (commitErr) {
                    console.error("Transaction commit failed:", commitErr);
                } else {
                    console.log("🎉 Success! Re-populated database with balanced 90 days test data!");
                }
                db.close();
                process.exit(commitErr ? 1 : 0);
            });
        });
    });
});
