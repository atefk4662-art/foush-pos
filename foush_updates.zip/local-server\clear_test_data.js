const sqlite3 = require('sqlite3').verbose();
const crypto = require('crypto');
const path = require('path');

const dbPath = path.resolve(__dirname, 'foush.db');
const db = new sqlite3.Database(dbPath);

db.get('SELECT data FROM app_state WHERE id = 1', (err, row) => {
    if (err || !row) {
        console.error("Database error or no state row:", err);
        process.exit(1);
    }

    let data;
    try {
        data = JSON.parse(row.data);
    } catch(e) {
        data = {};
    }

    // Retain only configurations, wipe transactional data
    const cleanState = {
        menu: data.menu || [],
        employees: data.employees || [],
        tables: data.tables || [],
        settings: data.settings || {},
        orders: [],
        shift: null,
        historical_orders: [],
        exp: [],
        shifts_history: [],
        stock_history: [],
        waste_log: [],
        attendance: data.attendance || [] // Keep employee attendance or wipe if preferred (let's keep for now)
    };

    const rawData = JSON.stringify(cleanState);
    const newHash = crypto.createHash('md5').update(rawData).digest('hex');

    db.get('SELECT version FROM app_state WHERE id = 1', (err, stateRow) => {
        const nextVersion = (stateRow ? stateRow.version : 0) + 1;
        
        db.serialize(() => {
            db.run('BEGIN TRANSACTION');
            
            // 1. Update JSON state
            db.run('UPDATE app_state SET version = ?, hash = ?, data = ? WHERE id = 1', [nextVersion, newHash, rawData], function(updateErr) {
                if (updateErr) {
                    console.error("Failed to clear JSON state:", updateErr);
                    db.run('ROLLBACK');
                    process.exit(1);
                }
            });

            // 2. Clear SQL relational reporting tables
            db.run('DELETE FROM orders');
            db.run('DELETE FROM order_items');

            db.run('COMMIT', (commitErr) => {
                if (commitErr) {
                    console.error("Transaction commit failed:", commitErr);
                } else {
                    console.log("==============================================================");
                    console.log("✅ Success! All test sales, shifts, and expenses have been wiped!");
                    console.log("Menu, employees, and settings configurations were preserved.");
                    console.log("==============================================================");
                }
                db.close();
                process.exit(commitErr ? 1 : 0);
            });
        });
    });
});
